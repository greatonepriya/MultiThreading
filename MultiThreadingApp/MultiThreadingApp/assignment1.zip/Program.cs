﻿using System;

namespace MultiThreadingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            ProducerConsumer.StartProducerConsumer();
        }
    }
}
